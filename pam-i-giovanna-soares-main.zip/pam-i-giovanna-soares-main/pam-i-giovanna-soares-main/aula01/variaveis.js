// Pra rodar o Code Runner é só dar ctrl+alt+n

// primeira forma de declarar variavel, a forma antiga:
var Variavel_1 = 2;

// segunda forma de declarar varialvel, forma nova e preferencial:
let Variavel_2 = 4;

// terceria forma de declarar variavel, atribui dados apenas uma vez:
const Variavel_3 = "Olá Pessoal!";

// método = trecho que já existe num código
// função = é um conceito, não está atribuido a um objeto

// método, formas diferentyes de usar o console.log
console.log(Variavel_3);
console.log("Olá mundo!");
console.log("Mensagem", Variavel_3);
console.log("Mensagem" + Variavel_3);